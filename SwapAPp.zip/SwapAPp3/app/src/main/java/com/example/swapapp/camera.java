package com.example.swapapp;public class camera {
}
